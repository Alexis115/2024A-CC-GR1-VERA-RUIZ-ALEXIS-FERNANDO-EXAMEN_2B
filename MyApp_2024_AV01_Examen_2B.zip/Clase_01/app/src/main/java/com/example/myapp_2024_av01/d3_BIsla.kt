package com.example.myapp_2024_av01

import android.os.Parcel
import android.os.Parcelable

class d3_BIsla (
    var id:Int,
    var nombre:String?

): Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()
    ) {
    }

    override fun toString(): String {
        return "$nombre"
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(id)
        parcel.writeString(nombre)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<d3_BIsla> {
        override fun createFromParcel(parcel: Parcel): d3_BIsla {
            return d3_BIsla(parcel)
        }

        override fun newArray(size: Int): Array<d3_BIsla?> {
            return arrayOfNulls(size)
        }
    }

}