package com.example.myapp_2024_av01

class d3_BD_cultivos {

    companion object{
        val arregloBCultivo = arrayListOf<d3_BCultivo>()

        //Datos en memoria
        init {
            arregloBCultivo
                .add(
                    d3_BCultivo(1, "Coles", 80)
                )

            arregloBCultivo
                .add(
                    d3_BCultivo(2, "Patatas", 86)
                )

            arregloBCultivo
                .add(
                    d3_BCultivo(3, "Zanahoria", 0)
                )
        }
    }


}