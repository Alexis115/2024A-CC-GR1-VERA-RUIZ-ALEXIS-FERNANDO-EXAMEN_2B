package com.example.myapp_2024_av01

import android.os.Parcel
import android.os.Parcelable

class d3_BD_islas {

    companion object{
        val arregloBIsla = arrayListOf<d3_BIsla>()

        //Datos en memoria
        init {
            arregloBIsla
                .add(
                    d3_BIsla(1, "Thetford")
                )

            arregloBIsla
                .add(
                    d3_BIsla(2, "Martlock")
                )

            arregloBIsla
                .add(
                    d3_BIsla(3, "Lymhurst")
                )
        }
    }


}