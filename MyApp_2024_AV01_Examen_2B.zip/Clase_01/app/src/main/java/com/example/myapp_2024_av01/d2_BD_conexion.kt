package com.example.myapp_2024_av01

class d2_BD_conexion {

    companion object{
        val arregloConexion = arrayListOf<d2_Conexion>()

        //Datos en memoria
        init {
            arregloConexion
                .add(
                    d2_Conexion("Twitch")
                )

            arregloConexion
                .add(
                    d2_Conexion("Facebook")
                )

            arregloConexion
                .add(
                    d2_Conexion("Youtube")
                )
        }
    }


}