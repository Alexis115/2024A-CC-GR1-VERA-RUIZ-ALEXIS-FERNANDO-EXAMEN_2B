package com.example.myapp_2024_av01

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class d2_Adaptador_Conexion(
    private val contexto: d2_recycler_view_profile,
    private val lista: ArrayList<d2_Conexion>,
    private val recyclerView: RecyclerView
) : RecyclerView.Adapter<
        d2_Adaptador_Conexion.MyViewHolder
        >() {

    //Obtenemos los siguientes diferentes componenetes visuales
    inner class MyViewHolder(
        view: View
    ): RecyclerView.ViewHolder(view){
        //Obtenemos los siguientes diferentes componenetes visuales
        val conexionTextView: TextView

        init {
            conexionTextView = view.findViewById(R.id.tv_conexion_d2)
        }


    }

    //Stetear el layout que vamos a utilizar
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.d2_recycler_view_conexion, parent, false)
        return MyViewHolder(itemView)

    }

    override fun getItemCount(): Int {
        return this.lista.size
    }

    //Setear los datos para la iteracion
    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val conexionActual = this.lista[position]
        holder.conexionTextView.text = conexionActual.conexion

    }
}