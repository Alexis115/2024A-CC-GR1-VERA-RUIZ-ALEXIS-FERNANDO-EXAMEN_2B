package com.example.myapp_2024_av01

class BBaseDatosMemoria {

    companion object{
        val arregloBEntrenador = arrayListOf<BEntrenador>()

        //Datos en memoria
        init {
            arregloBEntrenador
                .add(
                    BEntrenador(1, "Adrian", "a@a.com")
                )

            arregloBEntrenador
                .add(
                    BEntrenador(2, "Jose", "b@b.com")
                )

            arregloBEntrenador
                .add(
                    BEntrenador(3, "Carlos", "c@c.com")
                )
        }
    }


}